import sqlite3
import os
import csv
import logging
import re
import time
import io
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, jsonify, send_file
)
from pydantic import BaseModel, Field, field_validator, ValidationError
import bcrypt

# ==========================================
# APP SETUP
# ==========================================

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "campus-hardware-secret-2025-change-in-prod")

# ==========================================
# LOGGING
# ==========================================

log_dir = "app_logging"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

logging.basicConfig(
    filename=os.path.join(log_dir, "app.log"),
    level=logging.INFO,
    format="%(asctime)s - [%(levelname)s] - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("CampusHardwareLogger")

# ==========================================
# CONSTANTS
# ==========================================

DB_NAME = "hardware_inventory.db"
ROLE_USER = "User"
ROLE_ADMIN = "Admin"
ROLE_SUPER_ADMIN = "SuperAdmin"
SUPER_ADMIN_USERNAME = "Lance1015"
SUPER_ADMIN_PASSWORD = "Lance@1015"
VALID_ROLES = (ROLE_USER, ROLE_ADMIN, ROLE_SUPER_ADMIN)
PRIVILEGED_ROLES = (ROLE_ADMIN, ROLE_SUPER_ADMIN)
MAX_FAILED_ATTEMPTS = 3

# ==========================================
# DATABASE INITIALIZATION
# ==========================================

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT,
                password_hash TEXT NOT NULL,
                failed_attempts INTEGER DEFAULT 0,
                locked_until REAL DEFAULT 0,
                role TEXT DEFAULT 'User',
                locked INTEGER DEFAULT 0
            )
        """)

        cursor.execute("PRAGMA table_info(users)")
        existing_columns = [col[1] for col in cursor.fetchall()]
        migrations = [
            ("email", "ALTER TABLE users ADD COLUMN email TEXT"),
            ("failed_attempts", "ALTER TABLE users ADD COLUMN failed_attempts INTEGER DEFAULT 0"),
            ("locked_until", "ALTER TABLE users ADD COLUMN locked_until REAL DEFAULT 0"),
            ("role", "ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'User'"),
            ("locked", "ALTER TABLE users ADD COLUMN locked INTEGER DEFAULT 0"),
        ]
        for col, sql in migrations:
            if col not in existing_columns:
                cursor.execute(sql)
                logger.info(f"Migration: added {col}")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS hardware (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_name TEXT UNIQUE NOT NULL,
                category TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                status TEXT NOT NULL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS account_requests (
                request_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending'
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS borrow_requests (
                request_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                item_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                batch_id TEXT,
                FOREIGN KEY (item_id) REFERENCES hardware(item_id)
            )
        """)

        cursor.execute("PRAGMA table_info(borrow_requests)")
        borrow_cols = [col[1] for col in cursor.fetchall()]
        if "batch_id" not in borrow_cols:
            cursor.execute("ALTER TABLE borrow_requests ADD COLUMN batch_id TEXT")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reset_requests (
                request_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                email TEXT NOT NULL,
                new_password_hash TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending'
            )
        """)

        # Ensure SuperAdmin exists
        super_hash = bcrypt.hashpw(
            SUPER_ADMIN_PASSWORD.encode("utf-8"), bcrypt.gensalt()
        ).decode("utf-8")

        cursor.execute("SELECT id FROM users WHERE username = ?", (SUPER_ADMIN_USERNAME,))
        if not cursor.fetchone():
            cursor.execute("""
                INSERT INTO users (username, email, password_hash, failed_attempts, locked_until, role, locked)
                VALUES (?, ?, ?, 0, 0, ?, 0)
            """, (SUPER_ADMIN_USERNAME, "superadmin@campushardware.local", super_hash, ROLE_SUPER_ADMIN))
            logger.info("SuperAdmin account created.")
        else:
            cursor.execute(
                "UPDATE users SET role = ?, password_hash = ?, locked = 0, failed_attempts = 0 WHERE username = ?",
                (ROLE_SUPER_ADMIN, super_hash, SUPER_ADMIN_USERNAME)
            )

        conn.commit()
        conn.close()
        logger.info("Database initialized.")
    except sqlite3.Error as e:
        logger.error(f"DB init error: {e}")

# ==========================================
# VALIDATION SCHEMAS
# ==========================================

def validate_password_rules(v):
    if len(v) < 8:
        raise ValueError("Password must contain at least 8 characters.")
    if not re.search(r"[A-Z]", v):
        raise ValueError("Password must contain at least one uppercase letter.")
    if not re.search(r"[0-9]", v):
        raise ValueError("Password must contain at least one number.")
    if not re.search(r"[@#$%^&*]", v):
        raise ValueError("Password must contain at least one special character (@#$%^&*).")
    return v

class UserRegisterSchema(BaseModel):
    username: str = Field(..., min_length=3, max_length=20)
    email: str
    password: str
    role: str

    @field_validator("username")
    @classmethod
    def username_alphanumeric(cls, v):
        if not re.match(r"^[a-zA-Z0-9_]+$", v):
            raise ValueError("Username must contain only letters, numbers, and underscores.")
        return v

    @field_validator("email")
    @classmethod
    def validate_email(cls, v):
        v = v.strip().lower()
        if not re.match(r"^[a-zA-Z0-9._%+-]+@(gmail\.com|yahoo\.com)$", v):
            raise ValueError("Email must be a valid @gmail.com or @yahoo.com address.")
        return v

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        return validate_password_rules(v)

    @field_validator("role")
    @classmethod
    def validate_role(cls, v):
        if v not in VALID_ROLES:
            raise ValueError(f"Role must be one of: {', '.join(VALID_ROLES)}.")
        return v

class PasswordResetSchema(BaseModel):
    username: str = Field(..., min_length=1)
    email: str
    password: str

    @field_validator("email")
    @classmethod
    def validate_email(cls, v):
        v = v.strip().lower()
        if not re.match(r"^[a-zA-Z0-9._%+-]+@(gmail\.com|yahoo\.com)$", v):
            raise ValueError("Email must be a valid @gmail.com or @yahoo.com address.")
        return v

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        return validate_password_rules(v)

class HardwareSchema(BaseModel):
    item_name: str = Field(..., min_length=2, max_length=100)
    category: str = Field(..., min_length=2, max_length=50)
    quantity: int = Field(..., ge=0)
    unit_price: float = Field(..., ge=0.0)

def calculate_status(quantity: int) -> str:
    if quantity > 5:
        return "In Stock"
    elif 1 <= quantity <= 5:
        return "Low Stock"
    else:
        return "Out of Stock"

def get_password_requirements(password):
    missing = []
    if len(password) < 8:
        missing.append("at least 8 characters")
    if not re.search(r"[A-Z]", password):
        missing.append("one uppercase letter")
    if not re.search(r"[0-9]", password):
        missing.append("one number")
    if not re.search(r"[@#$%^&*]", password):
        missing.append("one special character (@#$%^&*)")
    return missing

# ==========================================
# AUTH DECORATORS
# ==========================================

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "username" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "username" not in session:
            return redirect(url_for("login"))
        if session.get("role") not in PRIVILEGED_ROLES:
            flash("Admin access required.", "danger")
            return redirect(url_for("catalog"))
        return f(*args, **kwargs)
    return decorated

def super_admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "username" not in session:
            return redirect(url_for("login"))
        if session.get("role") != ROLE_SUPER_ADMIN:
            flash("SuperAdmin access required.", "danger")
            return redirect(url_for("catalog"))
        return f(*args, **kwargs)
    return decorated

# ==========================================
# AUTH ROUTES
# ==========================================

@app.route("/", methods=["GET"])
def index():
    if "username" in session:
        return redirect(url_for("catalog"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if "username" in session:
        return redirect(url_for("catalog"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not username or not password:
            flash("Please enter both username and password.", "danger")
            return render_template("login.html")

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT password_hash, failed_attempts, role, locked FROM users WHERE username = ?",
            (username,)
        )
        row = cursor.fetchone()

        if not row:
            conn.close()
            logger.warning(f"Failed login for unknown user '{username}'")
            flash("Invalid username or password.", "danger")
            return render_template("login.html")

        password_hash = row["password_hash"]
        failed_attempts = row["failed_attempts"] or 0
        role = row["role"] or ROLE_USER
        locked = row["locked"] or 0
        is_privileged = role in PRIVILEGED_ROLES

        if locked and not is_privileged:
            conn.close()
            flash("Your account is locked due to too many failed attempts. Please reset your password.", "danger")
            return redirect(url_for("reset_password"))

        password_correct = bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))

        if password_correct:
            cursor.execute("UPDATE users SET failed_attempts = 0 WHERE username = ?", (username,))
            conn.commit()
            conn.close()
            session["username"] = username
            session["role"] = role
            logger.info(f"User '{username}' logged in as '{role}'.")
            flash(f"Welcome back, {username}!", "success")
            return redirect(url_for("catalog"))

        # Failed login
        failed_attempts += 1
        if is_privileged:
            cursor.execute("UPDATE users SET failed_attempts = ? WHERE username = ?", (failed_attempts, username))
            conn.commit()
            conn.close()
            flash("Invalid username or password.", "danger")
            return render_template("login.html")

        if failed_attempts >= MAX_FAILED_ATTEMPTS:
            cursor.execute("UPDATE users SET failed_attempts = ?, locked = 1 WHERE username = ?", (failed_attempts, username))
            conn.commit()
            conn.close()
            logger.warning(f"Account '{username}' locked after {failed_attempts} failed attempts.")
            flash("Too many failed attempts. Your account is locked. Please reset your password.", "danger")
            return redirect(url_for("reset_password"))
        else:
            cursor.execute("UPDATE users SET failed_attempts = ? WHERE username = ?", (failed_attempts, username))
            conn.commit()
            conn.close()
            remaining = MAX_FAILED_ATTEMPTS - failed_attempts
            flash(f"Invalid username or password. {remaining} attempt(s) remaining before lockout.", "danger")
            return render_template("login.html")

    return render_template("login.html")

@app.route("/logout")
def logout():
    username = session.get("username", "unknown")
    session.clear()
    logger.info(f"User '{username}' logged out.")
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if "username" in session:
        return redirect(url_for("catalog"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", ROLE_USER)

        try:
            validated = UserRegisterSchema(username=username, email=email, password=password, role=role)
        except ValidationError as e:
            flash(f"Validation Error: {e.errors()[0]['msg']}", "danger")
            return render_template("register.html", roles=[ROLE_USER, ROLE_ADMIN])

        if validated.username == SUPER_ADMIN_USERNAME or validated.role == ROLE_SUPER_ADMIN:
            flash("SuperAdmin accounts cannot be created through registration.", "danger")
            return render_template("register.html", roles=[ROLE_USER, ROLE_ADMIN])

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT username FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)",
            (validated.username, validated.email)
        )
        if cursor.fetchone():
            conn.close()
            flash("Username or email already registered.", "danger")
            return render_template("register.html", roles=[ROLE_USER, ROLE_ADMIN])

        cursor.execute(
            "SELECT request_id FROM account_requests WHERE status = 'pending' AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?))",
            (validated.username, validated.email)
        )
        if cursor.fetchone():
            conn.close()
            flash("A pending request with this username or email already exists.", "warning")
            return render_template("register.html", roles=[ROLE_USER, ROLE_ADMIN])

        hashed_pw = bcrypt.hashpw(validated.password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            cursor.execute("""
                INSERT INTO account_requests (username, email, password_hash, role, timestamp, status)
                VALUES (?, ?, ?, ?, ?, 'pending')
            """, (validated.username, validated.email, hashed_pw, validated.role, timestamp))
            conn.commit()
            logger.info(f"Account request submitted for '{validated.username}'.")
            flash("Account request submitted! A SuperAdmin must approve it before you can log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("An account request for this username already exists.", "danger")
        finally:
            conn.close()

    return render_template("register.html", roles=[ROLE_USER, ROLE_ADMIN])

@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    if "username" in session:
        return redirect(url_for("catalog"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not username:
            flash("Please enter the account username.", "danger")
            return render_template("reset_password.html")

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT email FROM users WHERE username = ?", (username,))
        row = cursor.fetchone()

        if not row:
            conn.close()
            flash("No account found with that username.", "danger")
            return render_template("reset_password.html")

        registered_email = (row["email"] or "").strip().lower()

        if not re.match(r"^[a-zA-Z0-9._%+-]+@(gmail\.com|yahoo\.com)$", email.strip().lower()):
            conn.close()
            flash("Email must be a valid @gmail.com or @yahoo.com address.", "danger")
            return render_template("reset_password.html")

        if email.strip().lower() != registered_email:
            conn.close()
            flash("The email does not match our records for this username.", "danger")
            return render_template("reset_password.html")

        try:
            validated = PasswordResetSchema(username=username, email=email, password=new_password)
        except ValidationError as e:
            conn.close()
            flash(f"Validation Error: {e.errors()[0]['msg']}", "danger")
            return render_template("reset_password.html")

        if new_password != confirm_password:
            conn.close()
            flash("Passwords do not match.", "danger")
            return render_template("reset_password.html")

        hashed_pw = bcrypt.hashpw(validated.password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
            INSERT INTO reset_requests (username, email, new_password_hash, timestamp, status)
            VALUES (?, ?, ?, ?, 'pending')
        """, (username, registered_email, hashed_pw, timestamp))
        conn.commit()
        conn.close()
        logger.info(f"Password reset request submitted for '{username}'.")
        flash("Reset request submitted. An administrator must approve it before you can log in again.", "success")
        return redirect(url_for("login"))

    return render_template("reset_password.html")

# ==========================================
# CATALOG (all roles)
# ==========================================

@app.route("/catalog")
@login_required
def catalog():
    conn = get_db()
    cursor = conn.cursor()
    category = request.args.get("category", "All Categories")
    search = request.args.get("search", "")

    query = "SELECT item_id, item_name, category, quantity, unit_price, status FROM hardware WHERE 1=1"
    params = []
    if category and category != "All Categories":
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND LOWER(item_name) LIKE ?"
        params.append(f"%{search.strip().lower()}%")
    query += " ORDER BY item_name ASC"
    cursor.execute(query, params)
    items = cursor.fetchall()

    cursor.execute("SELECT DISTINCT category FROM hardware ORDER BY category ASC")
    categories = ["All Categories"] + [r["category"] for r in cursor.fetchall()]

    cursor.execute("SELECT SUM(quantity * unit_price) FROM hardware")
    total = cursor.fetchone()[0] or 0.0
    conn.close()

    cart = session.get("cart", [])
    return render_template("catalog.html",
        items=items, categories=categories, total_value=total,
        selected_category=category, search=search, cart=cart,
        role=session.get("role"), username=session.get("username")
    )

# ==========================================
# CART (User role)
# ==========================================

@app.route("/cart/add", methods=["POST"])
@login_required
def cart_add():
    if session.get("role") in PRIVILEGED_ROLES:
        return jsonify({"success": False, "message": "Admins cannot borrow items."})

    item_id = request.form.get("item_id")
    qty_str = request.form.get("quantity", "1")

    try:
        qty = int(qty_str)
        if qty <= 0:
            raise ValueError
    except ValueError:
        return jsonify({"success": False, "message": "Invalid quantity."})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT item_id, item_name, quantity FROM hardware WHERE item_id = ?", (item_id,))
    item = cursor.fetchone()
    conn.close()

    if not item:
        return jsonify({"success": False, "message": "Item not found."})

    available = item["quantity"]
    cart = session.get("cart", [])
    already_in_cart = sum(c["quantity"] for c in cart if str(c["item_id"]) == str(item_id))

    if qty + already_in_cart > available:
        return jsonify({"success": False, "message": f"Only {available} unit(s) available ({already_in_cart} already in cart)."})

    for c in cart:
        if str(c["item_id"]) == str(item_id):
            c["quantity"] += qty
            session["cart"] = cart
            return jsonify({"success": True, "message": f"Updated cart: {c['item_name']} x{c['quantity']}", "cart_count": sum(i["quantity"] for i in cart)})

    cart.append({"item_id": str(item_id), "item_name": item["item_name"], "quantity": qty, "available": available})
    session["cart"] = cart
    return jsonify({"success": True, "message": f"Added {item['item_name']} to cart.", "cart_count": sum(i["quantity"] for i in cart)})

@app.route("/cart/remove", methods=["POST"])
@login_required
def cart_remove():
    item_id = request.form.get("item_id")
    cart = session.get("cart", [])
    session["cart"] = [c for c in cart if str(c["item_id"]) != str(item_id)]
    return jsonify({"success": True, "cart_count": sum(i["quantity"] for i in session["cart"])})

@app.route("/cart/clear", methods=["POST"])
@login_required
def cart_clear():
    session["cart"] = []
    return jsonify({"success": True})

@app.route("/cart")
@login_required
def cart_view():
    if session.get("role") in PRIVILEGED_ROLES:
        flash("Admins manage inventory directly.", "info")
        return redirect(url_for("catalog"))
    cart = session.get("cart", [])
    return render_template("cart.html", cart=cart, username=session.get("username"), role=session.get("role"))

@app.route("/cart/submit", methods=["POST"])
@login_required
def cart_submit():
    username = session.get("username")
    cart = session.get("cart", [])

    if not cart:
        flash("Your cart is empty.", "warning")
        return redirect(url_for("cart_view"))

    conn = get_db()
    cursor = conn.cursor()
    try:
        validated_items = []
        for c in cart:
            item_id = c["item_id"]
            quantity = int(c["quantity"])
            if quantity <= 0:
                flash("Quantity must be at least 1.", "danger")
                return redirect(url_for("cart_view"))

            cursor.execute("SELECT item_name, quantity FROM hardware WHERE item_id = ?", (item_id,))
            item = cursor.fetchone()
            if not item:
                flash("An item in your cart was not found.", "danger")
                return redirect(url_for("cart_view"))

            if quantity > item["quantity"]:
                flash(f"Only {item['quantity']} unit(s) of '{item['item_name']}' available.", "danger")
                return redirect(url_for("cart_view"))

            cursor.execute(
                "SELECT request_id FROM borrow_requests WHERE username = ? AND item_id = ? AND status = 'pending'",
                (username, item_id)
            )
            if cursor.fetchone():
                flash(f"You already have a pending request for '{item['item_name']}'.", "warning")
                return redirect(url_for("cart_view"))

            validated_items.append((item_id, quantity, item["item_name"]))

        batch_id = f"{username}-{int(time.time() * 1000)}"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for item_id, quantity, item_name in validated_items:
            cursor.execute("""
                INSERT INTO borrow_requests (username, item_id, quantity, timestamp, status, batch_id)
                VALUES (?, ?, ?, ?, 'pending', ?)
            """, (username, item_id, quantity, timestamp, batch_id))

        conn.commit()
        session["cart"] = []
        logger.info(f"Borrow cart submitted by '{username}' (batch {batch_id}).")
        flash("Borrow request submitted for admin approval!", "success")
        return redirect(url_for("catalog"))

    except sqlite3.Error as e:
        conn.rollback()
        logger.error(f"Cart submit error: {e}")
        flash("Database error while submitting request.", "danger")
        return redirect(url_for("cart_view"))
    finally:
        conn.close()

# ==========================================
# INVENTORY MANAGEMENT (Admin/SuperAdmin)
# ==========================================

@app.route("/inventory/add", methods=["POST"])
@admin_required
def inventory_add():
    item_name = request.form.get("item_name", "").strip()
    category = request.form.get("category", "").strip()
    qty_str = request.form.get("quantity", "").strip()
    price_str = request.form.get("unit_price", "").strip()

    try:
        qty = int(qty_str)
        price = float(price_str)
        validated = HardwareSchema(item_name=item_name, category=category, quantity=qty, unit_price=price)
    except (ValueError, ValidationError) as e:
        msg = e.errors()[0]["msg"] if isinstance(e, ValidationError) else "Invalid numbers."
        flash(f"Validation Error: {msg}", "danger")
        return redirect(url_for("catalog"))

    status = calculate_status(validated.quantity)
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT item_id FROM hardware WHERE LOWER(item_name) = LOWER(?)", (validated.item_name.strip(),))
    if cursor.fetchone():
        conn.close()
        flash(f"An item named '{validated.item_name}' already exists.", "danger")
        return redirect(url_for("catalog"))

    try:
        cursor.execute("""
            INSERT INTO hardware (item_name, category, quantity, unit_price, status)
            VALUES (?, ?, ?, ?, ?)
        """, (validated.item_name.strip(), validated.category.strip(), validated.quantity, validated.unit_price, status))
        conn.commit()
        logger.info(f"Added hardware: '{validated.item_name}'")
        flash("Equipment added successfully!", "success")
    except sqlite3.IntegrityError:
        flash(f"An item named '{validated.item_name}' already exists.", "danger")
    finally:
        conn.close()

    return redirect(url_for("catalog"))

@app.route("/inventory/update/<int:item_id>", methods=["POST"])
@admin_required
def inventory_update(item_id):
    qty_str = request.form.get("quantity", "").strip()
    price_str = request.form.get("unit_price", "").strip()

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT quantity, unit_price FROM hardware WHERE item_id = ?", (item_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        flash("Item not found.", "danger")
        return redirect(url_for("catalog"))

    try:
        new_qty = int(qty_str) if qty_str else row["quantity"]
        new_price = float(price_str) if price_str else row["unit_price"]
        if new_qty < 0 or new_price < 0:
            raise ValueError
    except ValueError:
        conn.close()
        flash("Quantity must be a non-negative integer and price a valid number.", "danger")
        return redirect(url_for("catalog"))

    new_status = calculate_status(new_qty)
    cursor.execute(
        "UPDATE hardware SET quantity = ?, unit_price = ?, status = ? WHERE item_id = ?",
        (new_qty, new_price, new_status, item_id)
    )
    conn.commit()
    conn.close()
    logger.info(f"Hardware ID {item_id} updated.")
    flash("Record updated successfully!", "success")
    return redirect(url_for("catalog"))

@app.route("/inventory/delete/<int:item_id>", methods=["POST"])
@admin_required
def inventory_delete(item_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT item_name FROM hardware WHERE item_id = ?", (item_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        flash("Item not found.", "danger")
        return redirect(url_for("catalog"))

    cursor.execute("DELETE FROM hardware WHERE item_id = ?", (item_id,))
    conn.commit()
    conn.close()
    logger.info(f"Hardware ID {item_id} ('{row['item_name']}') deleted.")
    flash(f"'{row['item_name']}' deleted successfully.", "success")
    return redirect(url_for("catalog"))

@app.route("/inventory/export-csv")
@login_required
def export_csv():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT item_id, item_name, category, quantity, unit_price, status FROM hardware")
    rows = cursor.fetchall()
    conn.close()

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total = 0.0
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["=================================================="])
    writer.writerow(["CAMPUS HARDWARE INVENTORY MANAGEMENT REPORT"])
    writer.writerow([f"Generated On: {timestamp}"])
    writer.writerow([f"Total Recorded Items: {len(rows)}"])
    writer.writerow(["=================================================="])
    writer.writerow([])
    writer.writerow(["Item ID", "Item Name", "Category", "Quantity", "Unit Price", "Total Price", "Status"])

    for r in rows:
        item_total = r["quantity"] * r["unit_price"]
        total += item_total
        writer.writerow([r["item_id"], r["item_name"], r["category"], r["quantity"],
                         f"${r['unit_price']:,.2f}", f"${item_total:,.2f}", r["status"]])

    writer.writerow([])
    writer.writerow(["", "", "", "", "GRAND TOTAL ASSET VALUE:", f"${total:,.2f}", ""])
    output.seek(0)
    logger.info(f"CSV exported by '{session.get('username')}'.")
    return send_file(
        io.BytesIO(output.getvalue().encode("utf-8")),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"inventory_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    )

# ==========================================
# APPROVALS (Admin + SuperAdmin)
# ==========================================

@app.route("/approvals")
@admin_required
def approvals():
    conn = get_db()
    cursor = conn.cursor()

    # Borrow requests
    cursor.execute("""
        SELECT br.request_id, br.username, h.item_name, br.quantity, br.timestamp
        FROM borrow_requests br JOIN hardware h ON h.item_id = br.item_id
        WHERE br.status = 'pending' ORDER BY br.request_id ASC
    """)
    borrow_requests = cursor.fetchall()

    # Active borrows
    cursor.execute("""
        SELECT br.request_id, br.username, h.item_name, br.quantity, br.timestamp
        FROM borrow_requests br JOIN hardware h ON h.item_id = br.item_id
        WHERE br.status = 'approved' ORDER BY br.request_id ASC
    """)
    active_borrows = cursor.fetchall()

    # Reset requests
    cursor.execute("""
        SELECT request_id, username, email, timestamp FROM reset_requests
        WHERE status = 'pending' ORDER BY request_id ASC
    """)
    reset_requests = cursor.fetchall()

    # Account requests (SuperAdmin only)
    account_requests = []
    if session.get("role") == ROLE_SUPER_ADMIN:
        cursor.execute("""
            SELECT request_id, username, email, role, timestamp FROM account_requests
            WHERE status = 'pending' ORDER BY request_id ASC
        """)
        account_requests = cursor.fetchall()

    conn.close()
    return render_template("approvals.html",
        borrow_requests=borrow_requests, active_borrows=active_borrows,
        reset_requests=reset_requests, account_requests=account_requests,
        role=session.get("role"), username=session.get("username")
    )

@app.route("/approvals/borrow/approve/<int:request_id>", methods=["POST"])
@admin_required
def approve_borrow(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT br.username, br.item_id, br.quantity, br.status, h.item_name, h.quantity
        FROM borrow_requests br JOIN hardware h ON h.item_id = br.item_id
        WHERE br.request_id = ?
    """, (request_id,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        flash("Borrow request not found.", "danger")
        return redirect(url_for("approvals"))

    if row["status"] != "pending":
        conn.close()
        flash("This request has already been processed.", "warning")
        return redirect(url_for("approvals"))

    # row columns: username(0), item_id(1), quantity(2), status(3), item_name(4), h_quantity(5)
    br_qty    = row["quantity"]    # borrow quantity requested
    hw_qty    = row[5]             # hardware.quantity available

    if br_qty > hw_qty:
        conn.close()
        flash(f"Not enough inventory for '{row['item_name']}'.", "danger")
        return redirect(url_for("approvals"))

    new_qty = hw_qty - br_qty
    cursor.execute("UPDATE hardware SET quantity = ?, status = ? WHERE item_id = ?",
                   (new_qty, calculate_status(new_qty), row["item_id"]))
    cursor.execute("UPDATE borrow_requests SET status = 'approved' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    logger.info(f"Borrow #{request_id} approved.")
    flash(f"Approved: {row['quantity']} x '{row['item_name']}' released to {row['username']}.", "success")
    return redirect(url_for("approvals"))

@app.route("/approvals/borrow/reject/<int:request_id>", methods=["POST"])
@admin_required
def reject_borrow(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, status FROM borrow_requests WHERE request_id = ?", (request_id,))
    row = cursor.fetchone()
    if not row or row["status"] != "pending":
        conn.close()
        flash("Request not found or already processed.", "warning")
        return redirect(url_for("approvals"))
    cursor.execute("UPDATE borrow_requests SET status = 'rejected' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    logger.info(f"Borrow #{request_id} rejected.")
    flash(f"Borrow request for '{row['username']}' rejected.", "info")
    return redirect(url_for("approvals"))

@app.route("/approvals/borrow/return/<int:request_id>", methods=["POST"])
@admin_required
def mark_returned(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT br.username, br.item_id, br.quantity, br.status, h.item_name, h.quantity
        FROM borrow_requests br JOIN hardware h ON h.item_id = br.item_id
        WHERE br.request_id = ?
    """, (request_id,))
    row = cursor.fetchone()

    if not row or row["status"] != "approved":
        conn.close()
        flash("Record not found or not currently active.", "warning")
        return redirect(url_for("approvals"))

    hw_qty_current = row[5]
    br_qty = row["quantity"]
    new_qty = hw_qty_current + br_qty
    cursor.execute("UPDATE hardware SET quantity = ?, status = ? WHERE item_id = ?",
                   (new_qty, calculate_status(new_qty), row["item_id"]))
    cursor.execute("UPDATE borrow_requests SET status = 'returned' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    logger.info(f"Borrow #{request_id} returned.")
    flash(f"'{row['item_name']}' ({br_qty} unit(s)) returned and restocked.", "success")
    return redirect(url_for("approvals"))

@app.route("/approvals/reset/approve/<int:request_id>", methods=["POST"])
@admin_required
def approve_reset(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, new_password_hash, status FROM reset_requests WHERE request_id = ?", (request_id,))
    row = cursor.fetchone()
    if not row or row["status"] != "pending":
        conn.close()
        flash("Request not found or already processed.", "warning")
        return redirect(url_for("approvals"))

    cursor.execute("UPDATE users SET password_hash = ?, failed_attempts = 0, locked = 0 WHERE username = ?",
                   (row["new_password_hash"], row["username"]))
    cursor.execute("UPDATE reset_requests SET status = 'approved' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    logger.info(f"Reset #{request_id} approved for '{row['username']}'.")
    flash(f"Password reset approved for '{row['username']}'. Account unlocked.", "success")
    return redirect(url_for("approvals"))

@app.route("/approvals/reset/reject/<int:request_id>", methods=["POST"])
@admin_required
def reject_reset(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, status FROM reset_requests WHERE request_id = ?", (request_id,))
    row = cursor.fetchone()
    if not row or row["status"] != "pending":
        conn.close()
        flash("Request not found or already processed.", "warning")
        return redirect(url_for("approvals"))
    cursor.execute("UPDATE reset_requests SET status = 'rejected' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    flash(f"Reset request for '{row['username']}' rejected.", "info")
    return redirect(url_for("approvals"))

@app.route("/approvals/account/approve/<int:request_id>", methods=["POST"])
@super_admin_required
def approve_account(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, email, password_hash, role, status FROM account_requests WHERE request_id = ?", (request_id,))
    row = cursor.fetchone()
    if not row or row["status"] != "pending":
        conn.close()
        flash("Request not found or already processed.", "warning")
        return redirect(url_for("approvals"))

    cursor.execute(
        "SELECT 1 FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)",
        (row["username"], row["email"])
    )
    if cursor.fetchone():
        cursor.execute("UPDATE account_requests SET status = 'rejected' WHERE request_id = ?", (request_id,))
        conn.commit()
        conn.close()
        flash("Username or email already registered. Request rejected.", "danger")
        return redirect(url_for("approvals"))

    cursor.execute("""
        INSERT INTO users (username, email, password_hash, failed_attempts, locked_until, role, locked)
        VALUES (?, ?, ?, 0, 0, ?, 0)
    """, (row["username"], row["email"], row["password_hash"], row["role"]))
    cursor.execute("UPDATE account_requests SET status = 'approved' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    logger.info(f"Account '{row['username']}' approved.")
    flash(f"Account '{row['username']}' approved!", "success")
    return redirect(url_for("approvals"))

@app.route("/approvals/account/reject/<int:request_id>", methods=["POST"])
@super_admin_required
def reject_account(request_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, status FROM account_requests WHERE request_id = ?", (request_id,))
    row = cursor.fetchone()
    if not row or row["status"] != "pending":
        conn.close()
        flash("Request not found or already processed.", "warning")
        return redirect(url_for("approvals"))
    cursor.execute("UPDATE account_requests SET status = 'rejected' WHERE request_id = ?", (request_id,))
    conn.commit()
    conn.close()
    flash(f"Account request for '{row['username']}' rejected.", "info")
    return redirect(url_for("approvals"))

# ==========================================
# MANAGE ACCOUNTS (SuperAdmin)
# ==========================================

@app.route("/accounts")
@super_admin_required
def manage_accounts():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT username, email, role, locked FROM users
        WHERE username != ? ORDER BY role ASC, username ASC
    """, (SUPER_ADMIN_USERNAME,))
    accounts = cursor.fetchall()
    conn.close()
    return render_template("accounts.html", accounts=accounts, username=session.get("username"), role=session.get("role"))

@app.route("/accounts/remove/<username>", methods=["POST"])
@super_admin_required
def remove_account(username):
    if username == SUPER_ADMIN_USERNAME:
        flash("The permanent SuperAdmin account cannot be removed.", "danger")
        return redirect(url_for("manage_accounts"))

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        flash("Account not found.", "danger")
        return redirect(url_for("manage_accounts"))

    cursor.execute("DELETE FROM users WHERE username = ?", (username,))
    conn.commit()
    conn.close()
    logger.info(f"Account '{username}' removed by SuperAdmin.")
    flash(f"Account '{username}' removed.", "success")
    return redirect(url_for("manage_accounts"))

# ==========================================
# PROFILE (User role)
# ==========================================

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if session.get("role") in PRIVILEGED_ROLES:
        return redirect(url_for("catalog"))

    username = session.get("username")
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, email, role FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    conn.close()

    if request.method == "POST":
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if new_password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("profile.html", user=user, username=username, role=session.get("role"))

        missing = get_password_requirements(new_password)
        if missing:
            flash("Password is missing: " + ", ".join(missing) + ".", "danger")
            return render_template("profile.html", user=user, username=username, role=session.get("role"))

        hashed_pw = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET password_hash = ? WHERE username = ?", (hashed_pw, username))
        conn.commit()
        conn.close()
        logger.info(f"'{username}' updated their password.")
        flash("Password updated successfully!", "success")
        return redirect(url_for("profile"))

    return render_template("profile.html", user=user, username=username, role=session.get("role"))

# ==========================================
# PASSWORD STRENGTH API
# ==========================================

@app.route("/api/password-check", methods=["POST"])
def password_check():
    password = request.json.get("password", "")
    missing = get_password_requirements(password)
    return jsonify({"missing": missing, "valid": len(missing) == 0})

# ==========================================
# ENTRY POINT
# ==========================================

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
